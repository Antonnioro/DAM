package repaso

fun main(){
    val arrayValores1 = arrayOf(1, "Espana", 2, "Francia", 3, "Alemania", 4, "Italia", 5)
    for (i in 0 until arrayValores1.size) {
        println(arrayValores1[i])
    }
}