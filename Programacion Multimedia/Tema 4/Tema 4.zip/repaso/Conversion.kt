package repaso

fun main(){
    val numberString = "123"
    val number: Int = numberString.toInt()

    println(number)
}