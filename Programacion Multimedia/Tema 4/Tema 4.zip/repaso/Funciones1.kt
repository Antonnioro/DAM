package repaso

fun algo(ne: Int): Int {
    return ne
}

fun main() {
    var resultado = algo(5)
    println(resultado)
}