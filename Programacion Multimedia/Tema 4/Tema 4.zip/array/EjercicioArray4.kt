package array

fun main(){
    val arrayFloat = floatArrayOf(3.5F, 2.2f)
    for (i in 0 until arrayFloat.size){
        println(arrayFloat[i])
    }
}