package variables

fun main() {
    var alea:Int=(1..10).random()
    println(alea)
}