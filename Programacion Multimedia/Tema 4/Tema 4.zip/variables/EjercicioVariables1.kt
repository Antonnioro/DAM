package variables

fun main(){
    println("Hola mundo")

    var varia1: Int = 4
    var varia2: Int = 2
    var totalSuma: Int = varia1+varia2
    var totalResta: Int = varia1-varia2
    var totalMulti: Int = varia1*varia2
    var totalDivi: Int = varia1/varia2

    println("El resultado de la suma es " + (varia1+varia2))
    println("La suma es $totalSuma")

    println("El resultado de la resta es " + (varia1-varia2))
    println("La resta es $totalResta")

    println("El resultado de la multiplicacion es " + (varia1*varia2))
    println("La multiplicacion es $totalMulti")

    println("El resultado de la division es " + (varia1/varia2))
    println("La division es $totalDivi")

}