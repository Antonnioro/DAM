package conversiones

fun main(){
    var numero = "123"
    var numeroconversion = numero.toInt()
    println(numeroconversion)
}