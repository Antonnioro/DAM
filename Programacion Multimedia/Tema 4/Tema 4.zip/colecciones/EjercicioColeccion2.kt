package colecciones

//No permite elementos ducplicados

fun main() {
    val conjunto: Set<String> = setOf("Uno", "Dos", "Tres")
    println(conjunto)
}