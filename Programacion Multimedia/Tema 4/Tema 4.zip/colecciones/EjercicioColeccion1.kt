package colecciones

//Coleccion ordenada de elementos.

fun main() {
    val lista: List<String> = listOf("Uno", "Dos", "Tres")
    println(lista)
}


